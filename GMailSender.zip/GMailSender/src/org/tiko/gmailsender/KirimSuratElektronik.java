package org.tiko.gmailsender;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

public class KirimSuratElektronik extends AsyncTask<Void, Void, Void> {
	// DEKLARASI VARIABEL
	private Context konteks;
	private Session sesi;

	// INFORMASI MENGIRIM EMAIL
	private String surel;
	private String subyek;
	private String pesan;

	// PROGRESS DIALOG -> tampil ketika proses mengirim surel
	private ProgressDialog pd;

	// MEMBUAT OBYEK/KONSTRUKTOR
	public KirimSuratElektronik(Context context, String email, String subject,
			String message) {
		this.konteks = context;
		this.surel = email;
		this.subyek = subject;
		this.pesan = message;
	}

	protected void onPreExecute() {
		super.onPreExecute();
		pd = ProgressDialog.show(konteks,
				"Sedang mengirim surat elektronik...", "Silakan menunggu");
	}

	protected void onPostExecute(Void aVoid) {
		super.onPostExecute(aVoid);
		pd.dismiss();
		Toast.makeText(konteks, "Surat terkirim!", Toast.LENGTH_LONG).show();
	}

	@Override
	protected Void doInBackground(Void... arg0) {
		// MEMBUAT PROPERTIS
		Properties props = new Properties();

		// KONFIGURASI PROPERTIS UNTUK GMAIL
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class",
				"javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");

		// MEMBUAT SESI BARU
		sesi = Session.getDefaultInstance(props,
				new javax.mail.Authenticator() {
					@SuppressWarnings("unused")
					protected PasswordAuthentication getAuthPass() {
						return new PasswordAuthentication(Konfigurasi.AKUN,
								Konfigurasi.KUNCI);
					}
				});
		try {
			// MEMBUAT obyek MIMEMESSAGE
			MimeMessage mm = new MimeMessage(sesi);

			// PENGATURAN ALAMAT PENGIRIM
			mm.setFrom(new InternetAddress(Konfigurasi.AKUN));
			// ALAMAT PENERIMA
			mm.setRecipient(Message.RecipientType.TO,
					new InternetAddress(surel));
			// MENAMBAHKAN SUBJECT
			mm.setSubject(subyek);
			// MENAMBAHKAN PESAN
			mm.setText(pesan);

			// MENGIRIM SUREL
			Transport.send(mm);

		} catch (MessagingException e) {
			e.printStackTrace();
		}
		return null;
	}
}
