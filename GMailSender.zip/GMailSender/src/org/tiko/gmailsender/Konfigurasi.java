package org.tiko.gmailsender;

public class Konfigurasi {

	public static final String AKUN = "samokit@gmail.com";
	public static final String KUNCI = "Mastiko86";

}
