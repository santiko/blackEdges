package org.tiko.gmailsender;

import javax.mail.Session;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity implements OnClickListener {
	Button tombolKirim;
	EditText txtAkunPenerima, txtIsiSurel, txtSubyek;
	Session sesi = null;
	ProgressDialog pd = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gmail_sender);
		txtAkunPenerima = (EditText) findViewById(R.id.teksAlamatPenerima);
		txtIsiSurel = (EditText) findViewById(R.id.teksIsiSurel);
		txtSubyek = (EditText) findViewById(R.id.teksSubyek);
		tombolKirim = (Button) findViewById(R.id.tombolKirim);
		tombolKirim.setOnClickListener(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public void kirimSurel() {
		String email = txtAkunPenerima.getText().toString();
		String message = txtIsiSurel.getText().toString();
		String subject = txtSubyek.getText().toString();

		// MEMBUAT OBYEK KirimSuratElektronik
		KirimSuratElektronik kse = new KirimSuratElektronik(this, email,
				subject, message);

		// EKSEKUSI
		kse.execute();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		kirimSurel();
	}
}
